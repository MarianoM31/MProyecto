<?php
include_once '../Model/ProductoModel.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Obtener todos los productos para mostrarlos en la vista
$productos = ObtenerTodosLosProductosModel();

// Insertar un nuevo producto
if (isset($_POST["btnInsertarProducto"])) {
    $nombre = $_POST["txtNombre"];
    $descripcion = $_POST["txtDescripcion"];
    $precio = $_POST["txtPrecio"];
    $marca = $_POST["txtMarca"];
    $stock = $_POST["txtStock"];

    $resultado = InsertarProductoModel($nombre, $descripcion, $precio, $marca, $stock);

    if ($resultado) {
        header('Location: ../View/gestionProducto.php');
        exit(); 
    } else {
        echo "Error al insertar el producto. Por favor, intenta nuevamente.";
    }
}

// Desactivar un producto (eliminar)
if (isset($_GET["accion"]) && $_GET["accion"] === "eliminar") {
    $id = $_GET["id"];
    if (!empty($id)) {
        $resultado = DesactivarProductoModel($id);

        if ($resultado) {
            header('Location: ../View/gestionProducto.php');
            exit(); 
        } else {
            echo "Error al eliminar el producto. Por favor, intenta nuevamente.";
        }
    } else {
        echo "ID del producto no proporcionado.";
    }
}
?>
