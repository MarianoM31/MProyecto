<?php
include_once '../Model/LoginModel.php';

class LoginController {

    public function login($emailUsername, $password) {
        // Crear instancia del modelo
        $loginModel = new LoginModel();
        
        // Autenticar al usuario utilizando el modelo
        $usuario = $loginModel->autenticarUsuario($emailUsername, $password);

        if ($usuario) {
            // Credenciales correctas
            session_start();
            $_SESSION['usuario'] = $usuario['Nombre_Completo']; 
            $_SESSION['rol'] = isset($usuario['Rol']) ? $usuario['Rol'] : 'cliente'; 

            // Mostrar alerta de inicio de sesión exitoso y redirigir al home.php
            echo "<script>
                    alert('Inicio de sesión exitoso. Redirigiendo a la página de inicio...');
                    window.location.href = '../View/home.php';
                  </script>";
            exit(); 
        } else {
            // Credenciales incorrectas
            return "Correo electrónico o contraseña incorrectos.";
        }
    }
}

?>
