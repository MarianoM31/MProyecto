<?php
include_once '../Model/resetPasswordModel.php';

class ResetPasswordController {
    public function resetPassword($token, $nuevaContrasena, $confirmarContrasena) {
        if ($nuevaContrasena !== $confirmarContrasena) {
            return "Las contraseñas no coinciden. Por favor, inténtalo de nuevo.";
        }

        $modelo = new ResetPasswordModel();
        return $modelo->actualizarContrasena($token, $nuevaContrasena);
    }
}
?>
