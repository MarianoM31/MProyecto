<?php
include_once 'BaseDatos.php';

// Insertar un producto
function InsertarProductoModel($nombre, $descripcion, $precio, $marca, $stock) {
    try {
        $enlace = AbrirBD();
        $sentencia = "CALL sp_insertarProducto('$nombre', '$descripcion', $precio, '$marca', $stock)";
        $resultado = $enlace->query($sentencia);
        CerrarBD($enlace);
        return $resultado;
    } catch (Exception $ex) {
        return null;
    }
}

// Actualizar un producto
function ActualizarProductoModel($id, $nombre, $descripcion, $precio, $marca, $stock) {
    try {
        $enlace = AbrirBD();
        $sentencia = "CALL sp_actualizarProducto($id, '$nombre', '$descripcion', $precio, '$marca', $stock)";
        $resultado = $enlace->query($sentencia);
        CerrarBD($enlace);
        return $resultado;
    } catch (Exception $ex) {
        return null;
    }
}

// Desactivar un producto
function DesactivarProductoModel($id) {
    try {
        $enlace = AbrirBD();
        $sentencia = "CALL sp_desactivarProducto($id)";
        $resultado = $enlace->query($sentencia);
        CerrarBD($enlace);
        return $resultado;
    } catch (Exception $ex) {
        return null;
    }
}

// Obtener todos los productos
function ObtenerTodosLosProductosModel() {
    try {
        $enlace = AbrirBD();
        $sentencia = "CALL sp_obtenerTodosLosProductos()";
        $resultado = $enlace->query($sentencia);
        $productos = [];

        if ($resultado) {
            $productos = $resultado->fetch_all(MYSQLI_ASSOC);
        }

        CerrarBD($enlace);
        return $productos;
    } catch (Exception $ex) {
        return [];
    }
}
?>
