<?php
require_once 'layout.php'; // Incluye el archivo layout.php

// Capturamos el contenido específico de la vista
ob_start();
?>
<h4 class="fw-bold py-3 mb-4">Gestión de Pedidos</h4>
<div class="card">
    <div class="card-header">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPedidoModal">Añadir Nuevo Pedido</button>
    </div>
    <div class="table-responsive text-nowrap">
        <table class="table">
            <thead>
                <tr>
                    <th>ID Pedido</th>
                    <th>Cliente</th>
                    <th>Fecha</th>
                    <th>Total</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>#001</td>
                    <td>Juan Pérez</td>
                    <td>10/10/2024</td>
                    <td>$150.00</td>
                    <td><span class="badge bg-success">Completado</span></td>
                    <td>
                        <button class="btn btn-sm btn-warning">Editar</button>
                        <button class="btn btn-sm btn-danger">Eliminar</button>
                    </td>
                </tr>
                <tr>
                    <td>#002</td>
                    <td>María López</td>
                    <td>11/10/2024</td>
                    <td>$80.00</td>
                    <td><span class="badge bg-warning">Pendiente</span></td>
                    <td>
                        <button class="btn btn-sm btn-warning">Editar</button>
                        <button class="btn btn-sm btn-danger">Eliminar</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal para añadir pedido -->
<div class="modal fade" id="addPedidoModal" tabindex="-1" aria-labelledby="addPedidoModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addPedidoModalLabel">Añadir Nuevo Pedido</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form>
                    <div class="mb-3">
                        <label for="pedidoCliente" class="form-label">Cliente</label>
                        <input type="text" class="form-control" id="pedidoCliente" required>
                    </div>
                    <div class="mb-3">
                        <label for="pedidoFecha" class="form-label">Fecha</label>
                        <input type="date" class="form-control" id="pedidoFecha" required>
                    </div>
                    <div class="mb-3">
                        <label for="pedidoTotal" class="form-label">Total</label>
                        <input type="number" class="form-control" id="pedidoTotal" required>
                    </div>
                    <div class="mb-3">
                        <label for="pedidoEstado" class="form-label">Estado</label>
                        <select class="form-select" id="pedidoEstado" required>
                            <option value="Pendiente">Pendiente</option>
                            <option value="Completado">Completado</option>
                            <option value="Cancelado">Cancelado</option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-primary">Guardar Pedido</button>
            </div>
        </div>
    </div>
</div>
<?php
$content = ob_get_clean(); // Capturamos el contenido de salida en la variable
LayoutGeneral('Gestión de Pedidos - Perfumería', $content); // Llamamos a la función layout con el contenido
?>
