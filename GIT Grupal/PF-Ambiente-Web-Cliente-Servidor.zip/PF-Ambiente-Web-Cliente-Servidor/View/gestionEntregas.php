<?php
require_once 'layout.php'; // Incluye el archivo layout.php

// Capturamos el contenido específico de la vista
ob_start();
?>
<h4 class="fw-bold py-3 mb-4">Gestión de Entregas</h4>
<div class="card">
    <div class="card-header">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEntregaModal">Añadir Nueva Entrega</button>
    </div>
    <div class="table-responsive text-nowrap">
        <table class="table">
            <thead>
                <tr>
                    <th>ID Entrega</th>
                    <th>Cliente</th>
                    <th>Dirección</th>
                    <th>Fecha de Entrega</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>#001</td>
                    <td>Juan Pérez</td>
                    <td>San José, Costa Rica</td>
                    <td>10/10/2024</td>
                    <td><span class="badge bg-success">Entregado</span></td>
                    <td>
                        <button class="btn btn-sm btn-warning">Editar</button>
                        <button class="btn btn-sm btn-danger">Eliminar</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal para añadir entrega -->
<div class="modal fade" id="addEntregaModal" tabindex="-1" aria-labelledby="addEntregaModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addEntregaModalLabel">Añadir Nueva Entrega</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form>
                    <div class="mb-3">
                        <label for="entregaCliente" class="form-label">Cliente</label>
                        <input type="text" class="form-control" id="entregaCliente" required>
                    </div>
                    <div class="mb-3">
                        <label for="entregaDireccion" class="form-label">Dirección</label>
                        <input type="text" class="form-control" id="entregaDireccion" required>
                    </div>
                    <div class="mb-3">
                        <label for="entregaFecha" class="form-label">Fecha de Entrega</label>
                        <input type="date" class="form-control" id="entregaFecha" required>
                    </div>
                    <div class="mb-3">
                        <label for="entregaEstado" class="form-label">Estado</label>
                        <select class="form-select" id="entregaEstado" required>
                            <option value="Pendiente">Pendiente</option>
                            <option value="Entregado">Entregado</option>
                            <option value="Cancelado">Cancelado</option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-primary">Guardar Entrega</button>
            </div>
        </div>
    </div>
</div>
<?php
$content = ob_get_clean(); // Capturamos el contenido de salida en la variable
LayoutGeneral('Gestión de Entregas - Perfumería', $content); // Llamamos a la función layout con el contenido
?>
