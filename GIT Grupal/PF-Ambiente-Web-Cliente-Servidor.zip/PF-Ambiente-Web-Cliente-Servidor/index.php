<?php
    header('Location: /PF-Ambiente-Web-Cliente-Servidor/View/home.php');
?>